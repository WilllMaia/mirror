﻿{
	"version": 1733722196,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"images/sprite-sheet0.png",
		"images/sprite2-sheet0.png",
		"images/smoke-sheet0.png",
		"images/smoke-sheet1.png",
		"images/smoke-sheet2.png",
		"images/smoke-sheet3.png",
		"images/smoke-sheet4.png",
		"images/smoke-sheet5.png",
		"media/bgm.ogg",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}